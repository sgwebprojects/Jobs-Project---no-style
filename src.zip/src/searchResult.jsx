import React from 'react'

export default function searchResult() {
  return (
    <div>
      
    </div>
  )
}
