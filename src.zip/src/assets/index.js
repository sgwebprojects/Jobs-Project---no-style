import backArrowIcon from "./backArrow.svg";
import uploadIcon from "./upload.svg";
import orLineIcon from "./orLine.svg";
import crossIcon from "./cross.svg";
import dragIcon from "./dragUpload.svg";
import addMore from "./addMore.svg";
import deleteIcon from "./delete.svg";
import leftArrow from "./leftArrow.svg";
import rightArrow from "./rightArrow.svg";
export {backArrowIcon,uploadIcon,orLineIcon,crossIcon,dragIcon,addMore,deleteIcon,leftArrow,rightArrow}