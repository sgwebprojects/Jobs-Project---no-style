import { createContext } from "react";

export const JobContext = createContext('')
export const EstPreviewContext = createContext('')
